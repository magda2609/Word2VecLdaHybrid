#!/usr/bin/perl
# created by juffi@cs.cmu.edu, 1997.

# MAKE-X-VAL
# creates a directory structure in the current directory that allows a 
# leave-1-university-out x-validation for the CMU 4 universities data set.

# assumption: 1 directory for each class, below it 1 directory for each source.

# Call:
# make-x-val <source-dir>

# BUGS: 
# The source-dir directory is handled a bit awkwardly: It is just 
# concatenated to the current working directory, which may result in 
# symbolic links containing ".." etc.

# read working-dir. All files will be generated here.
use Cwd 'chdir';
$workdir = $ENV{PWD};

# data sources for x-val
@sources = ("cornell", "texas", "washington", "wisconsin", "misc");

# this will not be left out
$exception = "misc";

# maindir is passed as arg.
$maindir = $ARGV[0];

# get class info
opendir(DIR, $maindir) or die "opendir $maindir: $!";
# @classes = grep($_ ne '.' && $_ ne '..' && -d $_, readdir(DIR));
# Why does the -d flag only let . and .. get through?
# Because I need the complete path to check whether its a dir!
@classes = grep($_ ne '.' && $_ ne '..' && -d "$maindir/$_", readdir(DIR));
closedir DIR;

# extract a pattern for starting the names of the new directories
$dirname = $maindir;
$dirname =~ s|^.*/(.*/?$)|$1|;

# loop over all sources except exceptions
foreach $source (@sources) {
    print "\nLeaving out $source...\n";
    next if ($source eq $exception);
    
    # Make new directory
    $newdir = "$dirname-sans-$source";
    mkdir ("$newdir",0777);
    
    # Make subs for each class
    foreach $class (@classes) {
	chdir ("$workdir/$newdir") or die "chdir ($workdir/$newdir): $!";
	mkdir ($class,0777);
	chdir ($class) or die "mkdir/chdir ($class): $!";

	# Make symbolic links for each source
	foreach $source2 (@sources) {
	    next if ($source2 eq $source);
            print "$workdir/$maindir/$class/$source2\n";
	    `ln -s $workdir/$maindir/$class/$source2/ $source2`;
	};
    };
    chdir ($workdir) or die "chdir ($workdir): $!";
};

# make the test files
foreach $source (@sources) {
    print "\nCreating Test $source...\n";
    next if ($source eq $exception);
    
    # Make new directory
    $newdir = "$dirname-test-$source";
    mkdir ("$newdir",0777);
    
    # Make symbolic links for each class
    foreach $class (@classes) {
	chdir ("$workdir/$newdir") or die "chdir ($workdir/$newdir): $!";

	print "$workdir/$maindir/$class/$source\n";
	`ln -s $workdir/$maindir/$class/$source/ $class`;
    };
    chdir ($workdir) or die "chdir ($workdir): $!";
};


